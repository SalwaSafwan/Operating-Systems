1:open your netbeans
2:press on open project
3:open CPCS361Group3pOurStaticCode
4:if you want to run program in input 1 so you should uncomments from input one line 45,then your output will be in file named(output)
  if you want to run program in input 2 so you should uncomments from input one line 46,then your output will be in file named(output)
  if you want to run program in input 3 so you should uncomments from input one line 47,then your output will be in file named(output)

